#ifndef __PLAT_AUDIO_H
#define __PLAT_AUDIO_H

struct kirkwood_asoc_platform_data {
	int burst;
};
#endif
