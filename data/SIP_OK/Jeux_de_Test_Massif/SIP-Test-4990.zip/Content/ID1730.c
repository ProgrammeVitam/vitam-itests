#define ATOMIC64_EXPORT EXPORT_SYMBOL

#include <linux/export.h>
#include <linux/atomic.h>
