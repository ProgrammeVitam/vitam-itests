/*
 * ATSTK1000 setup code: Daughterboard interface
 *
 * Copyright (C) 2007 Atmel Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#ifndef __ARCH_AVR32_BOARDS_ATSTK1000_ATSTK1000_H
#define __ARCH_AVR32_BOARDS_ATSTK1000_ATSTK1000_H

extern struct atmel_lcdfb_pdata atstk1000_lcdc_data;

void atstk1000_setup_j2_leds(void);

#endif /* __ARCH_AVR32_BOARDS_ATSTK1000_ATSTK1000_H */
