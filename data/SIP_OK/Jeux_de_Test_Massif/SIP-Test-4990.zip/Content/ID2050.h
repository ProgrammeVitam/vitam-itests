#ifndef __SPARC_BARRIER_H
#define __SPARC_BARRIER_H

#include <asm-generic/barrier.h>

#endif /* !(__SPARC_BARRIER_H) */
