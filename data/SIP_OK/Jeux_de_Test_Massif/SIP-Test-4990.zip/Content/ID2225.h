#ifndef BCM63XX_DEV_HSSPI_H
#define BCM63XX_DEV_HSSPI_H

#include <linux/types.h>

int bcm63xx_hsspi_register(void);

#endif /* BCM63XX_DEV_HSSPI_H */
