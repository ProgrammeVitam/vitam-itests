/*
 * Defines for rx51 boards
 */

#ifndef _OMAP_BOARD_RX51_H
#define _OMAP_BOARD_RX51_H

extern void __init rx51_peripherals_init(void);
extern void __init rx51_video_mem_init(void);

#endif
