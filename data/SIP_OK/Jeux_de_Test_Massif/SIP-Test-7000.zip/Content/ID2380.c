
#include <linux/export.h>
#include <asm/atomic.h>

#define __ATOMIC_LIB__

#include <asm/atomic_defs.h>
