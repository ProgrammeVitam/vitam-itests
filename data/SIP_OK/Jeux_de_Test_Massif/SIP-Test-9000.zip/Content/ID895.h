extern int aix_partition(struct parsed_partitions *state);
