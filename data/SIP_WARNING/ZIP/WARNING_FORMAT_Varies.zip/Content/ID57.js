<!-- hide script from old browsers
test=new Date()
day=test.getDate()
month=test.getMonth()
month=(month*1)+ 1
year=test.getFullYear()
document.write(" ",day,"/",month,"/",year," ")